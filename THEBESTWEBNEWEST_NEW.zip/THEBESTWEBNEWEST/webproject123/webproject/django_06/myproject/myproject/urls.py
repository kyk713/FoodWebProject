"""myproject URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/2.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.conf.urls import url
from myapp.views import sayhello, sayhello2, sayhello3
from django.views.generic import TemplateView
from myapp.views import ViewModelPost, CreateModelPost, UpdateModelPost, DeleteModelPost
from myapp.register import signup
from django.contrib.auth import views as auth_views
from django.conf import settings
from django.conf.urls.static import static

from myapp.views import Login
from myapp.views import LittleFoodView,Drinks,SweetWater
from myapp.views import ShopView,AddShopView,DropShopView
urlpatterns = [
    url('admin/', admin.site.urls),
    url(r'^$', sayhello),
    url(r'^hello/$', sayhello2),
    url(r'^base/$', sayhello3),
    url(r'^home/$', TemplateView.as_view(template_name='home.html'), name='home'),
    url(r'^try/$', TemplateView.as_view(template_name='try.html'), name='try'),
    url(r'^contact/$', TemplateView.as_view(template_name='contact.html'), name='contact'),

    # Food_type
    url(r'^drinks/$', Drinks.as_view(), name='drinks'),
    url(r'^sweetwater/$', SweetWater.as_view(), name='sweetwater'),
    url(r'^littlefood/$', LittleFoodView.as_view(), name='littlefood'),

    # Shopping
    url(r'^shop/$', ShopView.as_view(), name='shop'),
    url(r'^add_shop/$', AddShopView.as_view(), name='add_shop'),
    url(r'^drop_shop/$', DropShopView.as_view(), name='drop_shop'),


    url(r'^about/$', TemplateView.as_view(template_name='about.html'), name='about'),
    url(r'^login/$', Login.as_view(), name='login'),
    url(r'^list/$', ViewModelPost.as_view(), name='list'),
    url(r'^create/$', CreateModelPost.as_view(), name='create'),
    url(r'^update/(?P<id>\d)/$', UpdateModelPost.as_view(), name='update'),
    url(r'^delete/(?P<pk>\d)/$', DeleteModelPost.as_view(), name='delete'),
    url(r'^signup/?$', signup, name='signup'),
    url(r'^login/?$',auth_views.LoginView.as_view(template_name='login.html'), name='login'),
    url(r'^logout/?$',auth_views.LogoutView.as_view(template_name='home.html'),name='logout')
]+ static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)

if settings.DEBUG:
    # static files (images, css, javascript, etc.)
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)


















