from django.contrib import admin
from .models import ModelAuthor, ModelPost, GoodsInfo,ShoppingCar
# Register your models here.
admin.site.register(ModelAuthor)
admin.site.register(ModelPost)
admin.site.register(GoodsInfo)
admin.site.register(ShoppingCar)
