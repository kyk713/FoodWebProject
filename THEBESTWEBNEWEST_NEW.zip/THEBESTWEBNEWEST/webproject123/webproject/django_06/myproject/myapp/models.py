from django.db import models
from datetime import datetime
# Create your models here.

from django.contrib.auth.models import User
class ModelAuthor(models.Model):
    username = models.CharField(max_length=150, null=False, blank=False)

    def __str__(self):
        return self.username

class ModelPost(models.Model):
    title   = models.CharField(max_length=120)
    author  = models.ForeignKey(ModelAuthor, on_delete=models.CASCADE)
    content = models.TextField()
    created = models.DateTimeField(auto_now_add=True)
    updated = models.DateTimeField(auto_now=True)

    def __str__(self):
        return "Post from {} created at {}".format(self.author, self.created)

    class Meta:
        pass
    
    def get_absolute_url(self):
        return '/list/'


# detail
class GoodsInfo(models.Model):
    CLASSIFYS = (
        ('little_food', 'Little Food'),
        ('sweet_water', 'Sugar Water'),
        ('drink', 'Drinks'),
    )

    name = models.CharField(verbose_name='Products name', max_length=64)
    price = models.FloatField(max_length=9, null=True, default=0, verbose_name='Price')
    detail = models.CharField(verbose_name='Products details', max_length=300, default='')
    image = models.ImageField(verbose_name='Products image', upload_to='goods/%Y/%m/%d', blank=True)
    classify = models.CharField(verbose_name='Products type', choices=CLASSIFYS, max_length=36)
    add_time = models.DateTimeField(verbose_name='Edit time', auto_now_add=datetime.now())

    class Meta:
        verbose_name = 'Product informations'
        verbose_name_plural = verbose_name

    def __str__(self):
        return self.name


# Shopping cart
class ShoppingCar(models.Model):

    # user_id = models.ManyToManyField(User, on_delete=models.CASCADE, verbose_name='用户id')
    user_id = models.ForeignKey(User, on_delete=models.CASCADE, verbose_name='userid')
    good_id = models.IntegerField(verbose_name='productid')
    name = models.CharField(verbose_name='productname', max_length=64)
    price = models.FloatField(max_length=9, null=True, default=0, verbose_name='price')
    num = models.IntegerField(verbose_name='quantity',default=0)


    class Meta:
        verbose_name = 'Shopping Cart'
        verbose_name_plural = verbose_name

    def __str__(self):
        return self.name
    