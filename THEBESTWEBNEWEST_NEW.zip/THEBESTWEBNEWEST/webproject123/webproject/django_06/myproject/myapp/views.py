from django.shortcuts import render, redirect,render_to_response,HttpResponse
from django.http import HttpResponse, HttpResponseRedirect
from .models import ModelPost
from django.views.generic import ListView, CreateView, UpdateView, DeleteView
from django.urls import reverse
from django.contrib.auth.mixins import LoginRequiredMixin
from django.views.generic import TemplateView
from django.core.files.storage import FileSystemStorage
from django.contrib.auth import authenticate, login, logout

from django.views.generic import View



from .models import GoodsInfo, ShoppingCar


# Create your views here.
def sayhello(request):
        return HttpResponse("Hellow Django")

def sayhello2(request):
        return HttpResponse("Hello Django 2")

def sayhello3(request):
        return render(request, "base.html")
class ViewModelPost(ListView):
        queryset = ModelPost.objects.all()
        template_name = 'list.html'

class CreateModelPost(LoginRequiredMixin, CreateView):
        login_url = '/login/'
        model = ModelPost
        fields = '__all__'
        template_name = 'create_ModelPost_form.html'

        def form_valid(self, form):
                model = form.save(commit=False)
                model.save()
                return HttpResponseRedirect(reverse('list'))
                
class UpdateModelPost(UpdateView):
        model = ModelPost
        fields = ['title', 'author', 'content']
        template_name = 'update_ModelPost_form.html'

        def get_object(self, queryset=None):
                id = self.kwargs['id']
                return self.model.objects.get(id=id)

        def form_valid(self, form):
                model = form.save(commit=False)
                model.save()
                return HttpResponseRedirect(reverse('list'))

class DeleteModelPost(DeleteView):
        model = ModelPost
        template_name = 'delete_ModelPost_form.html'

        def get_success_url(self):
                return reverse('list')


class Login(View):

    def get(self,request):
        return render(request,'login.html')

    def post(self,request):
        # redirect_to = request.Re
        username = request.POST.get('username', '')
        password = request.POST.get('password', '')
        print(username)
        print(password)
        user = authenticate(username=username, password=password)
        if user and user.is_active:
            login(request, user)
            return HttpResponseRedirect(request.POST.get('next', '/') or '/')

        return HttpResponse('Login failed, username or password does not exist.')




# littlefood
class LittleFoodView(View):
    def get(self, request):
        goods = GoodsInfo.objects.filter(classify='little_food')
        return render(request, 'littlefood.html', {
            'goods': goods,
        })
# sugar water
class SweetWater(View):
    def get(self, request):
        goods = GoodsInfo.objects.filter(classify='sweet_water')
        return render(request, 'sweetwater.html', {
            'goods': goods,
        })
# drinks
class Drinks(View):
    def get(self, request):
        goods = GoodsInfo.objects.filter(classify='drink')
        return render(request, 'drinks.html', {
            'goods': goods,
        })

# cart
class ShopView(View):
    def get(self,request):
        user = request.user.id
        # shop_car = ShoppingCar.objects.filter(user_id_id=request.user.id)
        try:
            shop_car = ShoppingCar.objects.all().filter(user_id=request.user)
            return render(request, 'shop.html',{
                'shop_car': shop_car,
        })
        except:
            return redirect('login')

class AddShopView(View):

    def post(self,request):
        user = request.user.id
        print(user)

        good_id = request.POST.get('goods_id', '')
        good = GoodsInfo.objects.filter(id=int(good_id))
        good_name = good[0].name
        good_price = PRICE  = good[0].price
        # Get the existing items and traverse to see if the added items exist.
        shop_car = ShoppingCar.objects.all().filter(user_id=user).filter(good_id=good_id)
        # shop_car = ShoppingCar.objects.all().filter(user_id_id=request.user.id)


        # if shopping cart already have one , add one more
        if shop_car:
            num = shop_car.first().num + 1
            shop_car.update(num=num)

            # get Quantity

        # if not just add it
        else:
            car = ShoppingCar.objects.create(user_id_id=user,good_id=good_id, name=good_name, price=good_price, num=1)
            print(car)
            car.save()

        return HttpResponse('Already added to the shopping cart')

class DropShopView(View):

    def post(self,request):
        good_id = request.POST.get('goods_id', '')
        ShoppingCar.objects.filter(good_id=good_id).delete()
        return HttpResponse('Already added to the shopping cart')



        
                